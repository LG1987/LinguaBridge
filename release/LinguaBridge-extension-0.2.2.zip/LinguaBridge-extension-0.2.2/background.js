// src/core/constraints.ts
var RULES = [
  {
    id: "obligation",
    sourceTerms: ["\u5FC5\u987B", "\u52A1\u5FC5", "\u4E00\u5B9A\u8981", "\u5FC5\u9700", "\u5E94\u5F53"],
    targetMarkers: [/\b(must|shall|required?|have to|has to|need to|ensure|make sure)\b/i],
    message: "\u539F\u6587\u542B\u300C\u5FC5\u987B/\u52A1\u5FC5\u300D\uFF0C\u8BD1\u6587\u4E2D\u6CA1\u6709 must/shall/ensure \u4E4B\u7C7B\u7684\u5F3A\u5236\u8BED\u6C14\uFF0C\u53EF\u80FD\u88AB\u5F31\u5316\u3002"
  },
  {
    id: "prohibition",
    sourceTerms: ["\u4E0D\u5F97", "\u7981\u6B62", "\u4E25\u7981", "\u4E0D\u51C6", "\u4E0D\u8981", "\u4E0D\u80FD", "\u4E0D\u53EF", "\u52FF"],
    targetMarkers: [
      /\b(must not|mustn't|do not|don't|does not|doesn't|never|shall not|should not|shouldn't|cannot|can't|avoid|prohibited|forbidden|no)\b/i
    ],
    message: "\u539F\u6587\u542B\u5426\u5B9A/\u7981\u6B62\u7C7B\u8981\u6C42\uFF0C\u8BD1\u6587\u4E2D\u672A\u627E\u5230 must not / do not / never \u7B49\u5426\u5B9A\u8BCD\uFF0C\u5426\u5B9A\u7EA6\u675F\u53EF\u80FD\u4E22\u5931\u3002"
  },
  {
    id: "only-output",
    sourceTerms: ["\u53EA\u8F93\u51FA", "\u4EC5\u8F93\u51FA", "\u53EA\u8FD4\u56DE", "\u4EC5\u8FD4\u56DE", "\u53EA\u56DE\u590D", "\u4EC5\u56DE\u590D", "\u4E0D\u8981\u89E3\u91CA", "\u65E0\u9700\u89E3\u91CA", "\u53EA\u7ED9"],
    targetMarkers: [
      /\b(only|solely|exclusively|just)\b/i,
      /\b(no explanation|without explanation|do not explain|don't explain)\b/i
    ],
    message: "\u539F\u6587\u9650\u5236\u8F93\u51FA\u5F62\u5F0F\uFF08\u53EA\u8F93\u51FA/\u4E0D\u8981\u89E3\u91CA\uFF09\uFF0C\u8BD1\u6587\u4E2D\u672A\u89C1 only/solely/no explanation \u7B49\u9650\u5B9A\u3002"
  },
  {
    id: "exclusivity",
    sourceTerms: ["\u53EA\u80FD", "\u4EC5\u53EF", "\u4EC5\u9650", "\u552F\u4E00"],
    targetMarkers: [/\b(only|solely|exclusively|single|the one)\b/i],
    message: "\u539F\u6587\u542B\u6392\u4ED6\u8981\u6C42\uFF08\u53EA\u80FD/\u4EC5\u9650\uFF09\uFF0C\u8BD1\u6587\u672A\u4F53\u73B0 only/exclusively\u3002"
  },
  {
    id: "bounds",
    sourceTerms: ["\u81F3\u5C11", "\u6700\u591A", "\u4E0D\u8D85\u8FC7", "\u4E0D\u5C11\u4E8E", "\u4E0D\u591A\u4E8E", "\u4EE5\u5185", "\u4EE5\u4E0A"],
    targetMarkers: [
      /\b(at least|at most|no more than|no fewer than|no less than|maximum|minimum|up to|within)\b/i
    ],
    message: "\u539F\u6587\u542B\u6570\u91CF\u4E0A\u4E0B\u9650\uFF0C\u8BD1\u6587\u4E2D\u672A\u89C1 at least/at most/no more than \u7B49\u5BF9\u5E94\u9650\u5236\u3002"
  },
  {
    id: "conditional",
    sourceTerms: ["\u9664\u975E", "\u5426\u5219", "\u5982\u679C", "\u5047\u5982", "\u4E00\u65E6"],
    targetMarkers: [/\b(unless|otherwise|if|when|once|in case)\b/i],
    message: "\u539F\u6587\u542B\u6761\u4EF6\u5206\u652F\u8BCD\uFF0C\u8BD1\u6587\u672A\u4F53\u73B0 unless/if/otherwise\uFF0C\u6761\u4EF6\u5173\u7CFB\u53EF\u80FD\u88AB\u6539\u5199\u3002"
  },
  {
    id: "preserve",
    sourceTerms: ["\u4FDD\u6301", "\u4FDD\u7559", "\u4E0D\u53D8", "\u4E0D\u8981\u4FEE\u6539", "\u539F\u6837"],
    targetMarkers: [
      /\b(keep|preserve|retain|unchanged|do not (change|modify|alter)|don't (change|modify|alter)|as-is|verbatim)\b/i
    ],
    message: "\u539F\u6587\u8981\u6C42\u4FDD\u6301\u4E0D\u53D8\uFF0C\u8BD1\u6587\u672A\u4F53\u73B0 keep/preserve/unchanged\uFF0C\u4FEE\u6539\u8FB9\u754C\u53EF\u80FD\u88AB\u524A\u5F31\u3002"
  },
  {
    id: "stepwise",
    sourceTerms: ["\u4E00\u6B65\u4E00\u6B65", "\u9010\u6B65", "\u5206\u6B65\u9AA4", "\u6309\u6B65\u9AA4"],
    targetMarkers: [/\b(step by step|step-by-step|incrementally|one step at a time)\b/i],
    message: "\u539F\u6587\u8981\u6C42\u5206\u6B65\u6267\u884C\uFF0C\u8BD1\u6587\u672A\u4F53\u73B0 step by step\u3002"
  },
  {
    id: "language",
    sourceTerms: ["\u7528\u4E2D\u6587", "\u7528\u82F1\u6587", "\u82F1\u6587\u56DE\u7B54", "\u4E2D\u6587\u56DE\u7B54", "\u82F1\u6587\u8F93\u51FA", "\u4E2D\u6587\u8F93\u51FA"],
    targetMarkers: [/\b(in (english|chinese)|english|chinese)\b/i],
    message: "\u539F\u6587\u6307\u5B9A\u4E86\u8F93\u51FA\u8BED\u8A00\uFF0C\u8BF7\u786E\u8BA4\u8BD1\u6587\u4ECD\u7136\u8868\u8FBE\u4E86\u8BE5\u8BED\u8A00\u8981\u6C42\u3002"
  },
  {
    id: "format",
    sourceTerms: ["JSON", "Markdown", "YAML", "SQL", "\u7EAF\u6587\u672C", "\u8868\u683C"],
    targetMarkers: [/\b(json|markdown|yaml|sql|plain text|table)\b/i],
    message: "\u539F\u6587\u6307\u5B9A\u4E86\u8F93\u51FA\u683C\u5F0F\uFF0C\u8BD1\u6587\u4E2D\u672A\u89C1\u540C\u540D\u683C\u5F0F\u8BCD\uFF0C\u8BF7\u4EBA\u5DE5\u786E\u8BA4\u3002"
  }
];
var NEGATION_SOURCE = /[不没别勿未]|禁止|避免/g;
var NEGATION_TARGET = /\b(not|no|never|none|neither|nor|without|cannot|can't|don't|doesn't|isn't|aren't|won't)\b/gi;
function countMatches(text, pattern) {
  return [...text.matchAll(pattern)].length;
}
function checkConstraints(source, translated) {
  const warnings = [];
  for (const rule of RULES) {
    const hit = rule.sourceTerms.find((term) => source.includes(term));
    if (hit === void 0) continue;
    const satisfied = rule.targetMarkers.some((marker) => marker.test(translated));
    if (!satisfied) {
      warnings.push({
        ruleId: rule.id,
        severity: "warning",
        sourceTerm: hit,
        message: rule.message
      });
    }
  }
  const sourceNegations = countMatches(source, NEGATION_SOURCE);
  const targetNegations = countMatches(translated, NEGATION_TARGET);
  if (sourceNegations > 0 && targetNegations === 0) {
    warnings.push({
      ruleId: "negation",
      severity: "warning",
      sourceTerm: "\u5426\u5B9A\u8BCD",
      message: "\u539F\u6587\u542B\u5426\u5B9A\u8868\u8FBE\uFF0C\u8BD1\u6587\u4E2D\u5B8C\u5168\u6CA1\u6709\u5426\u5B9A\u8BCD\uFF0C\u8BF7\u9010\u53E5\u6838\u5BF9\u3002"
    });
  }
  return warnings;
}

// src/core/protect.ts
var PLACEHOLDER_SOURCE = String.raw`[\[［]\s*[\[［]\s*(\d{1,5})\s*[\]］]\s*[\]］]`;
var PLACEHOLDER_RE = new RegExp(PLACEHOLDER_SOURCE, "g");
var PLACEHOLDER_TEST_RE = new RegExp(PLACEHOLDER_SOURCE);
function reservedIndices(text) {
  const used = /* @__PURE__ */ new Set();
  for (const match of text.matchAll(PLACEHOLDER_RE)) {
    const value = Number(match[1]);
    if (Number.isSafeInteger(value)) used.add(value);
  }
  return used;
}
var RULES2 = [
  // Placeholder-looking text the user typed themselves: round-trip it verbatim
  // instead of mistaking it for a dropped/invented placeholder later.
  { kind: "literal", pattern: /[\[［]\s*[\[［]\s*\d{1,5}\s*[\]］]\s*[\]］]/g },
  // ```ts ... ``` / ~~~ ... ~~~ — closed fences only.
  // The lookbehind keeps the newline before the fence outside the match, and the
  // closing fence is anchored at a line start so trailing prose is never eaten.
  {
    kind: "fenced-code",
    pattern: /(?<=^|\n)[ \t]*(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?<=\n)[ \t]*\1[ \t]*(?=\n|$)/g
  },
  // Unterminated fence: protect to end of text rather than send raw code to the
  // engine. Runs after the closed-fence rule, so only leftovers match.
  {
    kind: "fenced-code",
    pattern: /(?<=^|\n)[ \t]*(`{3,}|~{3,})[^\n]*\n[\s\S]*$/g
  },
  // `inline code` (single/double backticks, no newlines)
  { kind: "inline-code", pattern: /(`{1,2})([^`\n]+?)\1/g },
  // Email before URL: an email would otherwise be swallowed by the URL rule.
  { kind: "email", pattern: /\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b/g },
  // http(s)://… and www.…
  { kind: "url", pattern: /\b(?:https?:\/\/|www\.)[^\s<>"'`）)\]】，。；]+/gi },
  // Windows drive paths, UNC paths, POSIX absolute paths, and relative file paths.
  { kind: "path", pattern: /\b[A-Za-z]:\\[^\s<>"'`|?*，。；)]+/g },
  { kind: "path", pattern: /\\\\[\w.$-]+\\[^\s<>"'`，。；)]+/g },
  { kind: "path", pattern: /(?<=\s|^)\/(?:[\w.@+-]+\/)+[\w.@+-]*/g },
  { kind: "path", pattern: /(?<![\w/])(?:[\w.-]+[\\/])+[\w.-]+\.[A-Za-z][\w]{0,7}\b/g },
  // Shell commands: known executable followed by at least one ASCII argument.
  {
    kind: "command",
    pattern: /(?<![\w`])(?:npm|pnpm|yarn|npx|bun|deno|git|gh|docker|kubectl|helm|terraform|gcloud|az|cargo|rustc|go|python|py|pip|node|dotnet|msbuild|nuget|cmake|make|curl|wget|pwsh|powershell|choco|winget|ffmpeg|ssh|scp|rsync|tar|zip|unzip|java|javac|mvn|gradle|tsc|vite|vitest|jest|eslint|prettier|pytest|uv|uvx)(?:\s+(?=[^\s]*[A-Za-z0-9._/\\:@=+~$%{}[\]()"'<>*|&;^-])[^\s，。；：！？、（）]+)+/g
  },
  // Environment variables: $env:NAME, $NAME, ${NAME}, %NAME%
  { kind: "env-var", pattern: /\$env:[A-Za-z_][\w]*/g },
  { kind: "env-var", pattern: /\$\{[A-Za-z_][\w]*\}/g },
  { kind: "env-var", pattern: /(?<![\w$])\$[A-Za-z_][\w]*/g },
  { kind: "env-var", pattern: /%[A-Za-z_][\w]*%/g },
  // {{handlebars}} style placeholders
  { kind: "template", pattern: /\{\{[^{}\n]+\}\}/g }
];
function applyRule(state, rule, nextIndex) {
  const replaced = state.masked.replace(rule.pattern, (...args) => {
    const groups = args.slice(0, -2);
    const match = groups;
    if (match[0] === void 0) return "";
    if (rule.skip?.(match)) return match[0];
    const original = match[0];
    if (rule.kind !== "literal" && PLACEHOLDER_TEST_RE.test(original)) return original;
    const index = nextIndex();
    const slot = {
      token: `[[${index}]]`,
      index,
      kind: rule.kind,
      original,
      restoredAs: original
    };
    state.slots.push(slot);
    return slot.token;
  });
  state.masked = replaced;
}
function applyGlossary(state, glossary, nextIndex) {
  const entries = [...glossary].filter((entry) => entry.source.trim().length > 0).sort((a, b) => b.source.length - a.source.length);
  for (const entry of entries) {
    const escaped = entry.source.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const isAsciiTerm = /^[\x20-\x7e]+$/.test(entry.source);
    const pattern = new RegExp(isAsciiTerm ? `\\b${escaped}\\b` : escaped, "g");
    state.masked = state.masked.replace(pattern, (hit) => {
      const index = nextIndex();
      const slot = {
        token: `[[${index}]]`,
        index,
        kind: "glossary",
        original: hit,
        restoredAs: entry.target ?? entry.source
      };
      state.slots.push(slot);
      return slot.token;
    });
  }
}
function mask(text, options = {}) {
  const state = { masked: text, slots: [] };
  const used = reservedIndices(text);
  let counter = 0;
  const nextIndex = () => {
    do {
      counter += 1;
    } while (used.has(counter));
    used.add(counter);
    return counter;
  };
  if (options.preserveCode !== false) {
    for (const rule of RULES2) applyRule(state, rule, nextIndex);
  }
  if (options.glossary && options.glossary.length > 0) {
    applyGlossary(state, options.glossary, nextIndex);
  }
  return state;
}
function toSegments(masked) {
  const byToken = /* @__PURE__ */ new Map();
  for (const slot of masked.slots) byToken.set(slot.token, slot);
  const segments = [];
  let cursor = 0;
  for (const match of masked.masked.matchAll(PLACEHOLDER_RE)) {
    const index = match.index ?? 0;
    if (index > cursor) {
      segments.push({ kind: "text", value: masked.masked.slice(cursor, index) });
    }
    const slot = byToken.get(match[0]) ?? masked.slots.find((entry) => entry.index === Number(match[1]));
    if (slot !== void 0) {
      segments.push({ kind: "protected", value: slot.restoredAs, slot });
    } else {
      segments.push({ kind: "text", value: match[0] });
    }
    cursor = index + match[0].length;
  }
  if (cursor < masked.masked.length) {
    segments.push({ kind: "text", value: masked.masked.slice(cursor) });
  }
  return segments;
}
function hasCjk(text) {
  return /[\u3400-\u4dbf\u4e00-\u9fff]/.test(text);
}

// src/core/types.ts
var TranslationError = class extends Error {
  kind;
  userMessage;
  status;
  detail;
  constructor(kind, userMessage, options = {}) {
    super(userMessage);
    this.name = "TranslationError";
    this.kind = kind;
    this.userMessage = userMessage;
    this.status = options.status;
    this.detail = options.detail;
    if (options.cause !== void 0) this.cause = options.cause;
  }
};

// src/core/pipeline.ts
var FormatIntegrityError = class extends Error {
  invalidSlots;
  constructor(invalidSlots) {
    super("\u8BD1\u6587\u683C\u5F0F\u6821\u9A8C\u5931\u8D25\uFF1A\u53D7\u4FDD\u62A4\u7684\u4EE3\u7801/\u94FE\u63A5\u5728\u91CD\u7EC4\u65F6\u4E22\u5931\u3002\u5DF2\u62D2\u7EDD\u5199\u5165\uFF0C\u8BF7\u624B\u52A8\u7FFB\u8BD1\u8FD9\u6BB5\u5185\u5BB9\u3002");
    this.name = "FormatIntegrityError";
    this.invalidSlots = invalidSlots;
  }
};
var EDGE_RE = /^(\s*)([\s\S]*?)(\s*)$/;
var CJK_PUNCTUATION = [
  [/，/g, ","],
  [/。/g, "."],
  [/；/g, ";"],
  [/：/g, ":"],
  [/！/g, "!"],
  [/？/g, "?"],
  [/（/g, "("],
  [/）/g, ")"],
  [/、/g, ","],
  [/[“”]/g, '"'],
  [/[‘’]/g, "'"],
  [/…/g, "..."]
];
function normalizePunctuation(text, targetIsEnglish) {
  if (!targetIsEnglish) return text;
  let output = text;
  for (const [pattern, replacement] of CJK_PUNCTUATION) {
    output = output.replace(pattern, replacement);
  }
  return output;
}
var LATIN_TAIL_RE = /[A-Za-z0-9)\]"'`]$/;
var LATIN_HEAD_RE = /^[A-Za-z0-9($"'`[]/;
function joinPieces(pieces, targetIsEnglish) {
  let output = "";
  for (const piece of pieces) {
    if (piece === "") continue;
    if (output !== "" && targetIsEnglish) {
      const tail = output[output.length - 1] ?? "";
      const head = piece[0] ?? "";
      if (LATIN_TAIL_RE.test(tail) && LATIN_HEAD_RE.test(head)) output += " ";
    }
    output += piece;
  }
  return output;
}
function splitEdges(chunk) {
  const match = EDGE_RE.exec(chunk);
  if (match === null) return { lead: "", core: chunk, trail: "" };
  return { lead: match[1] ?? "", core: match[2] ?? "", trail: match[3] ?? "" };
}
function hasTranslatableChars(text) {
  return /[A-Za-z\u3400-\u4dbf\u4e00-\u9fff]/.test(text);
}
async function translateChunk(core, options) {
  const result = await options.provider.translate(
    {
      text: core,
      sourceLanguage: options.sourceLanguage ?? "auto",
      targetLanguage: options.targetLanguage,
      mode: options.mode,
      ...options.chineseVariant !== void 0 ? { chineseVariant: options.chineseVariant } : {}
    },
    options.signal
  );
  return {
    text: result.translatedText.trim(),
    providerId: result.providerId,
    latencyMs: result.latencyMs,
    ...result.detectedSourceLanguage !== void 0 ? { detectedSourceLanguage: result.detectedSourceLanguage } : {},
    translated: true
  };
}
function previewOf(slot) {
  return {
    kind: slot.kind,
    preview: slot.original.length > 60 ? `${slot.original.slice(0, 60)}\u2026` : slot.original
  };
}
async function runPipeline(options) {
  const text = options.text;
  if (text.trim() === "") {
    throw new TranslationError("empty", "\u8F93\u5165\u6846\u662F\u7A7A\u7684\uFF0C\u6CA1\u6709\u53EF\u7FFB\u8BD1\u7684\u5185\u5BB9\u3002");
  }
  const target = options.targetLanguage;
  const isEnglishTarget = target.toLowerCase().startsWith("en");
  if (isEnglishTarget && !hasCjk(text)) {
    return {
      translatedText: text,
      providerId: "none",
      latencyMs: 0,
      warnings: ["\u8F93\u5165\u770B\u8D77\u6765\u5DF2\u7ECF\u662F\u82F1\u6587\uFF0C\u672A\u8C03\u7528\u7FFB\u8BD1\u5F15\u64CE\u3002"],
      restoredSlots: 0,
      skipped: true,
      constraints: []
    };
  }
  const masked = mask(text, {
    preserveCode: options.preserveCode !== false,
    ...options.glossary !== void 0 ? { glossary: options.glossary } : {}
  });
  const segments = toSegments(masked);
  const protectedCount = segments.filter((segment) => segment.kind === "protected").length;
  const proseSegments = segments.filter(
    (segment) => segment.kind === "text" && splitEdges(segment.value).core !== ""
  );
  if (proseSegments.length === 0) {
    return {
      translatedText: text,
      providerId: "none",
      latencyMs: 0,
      warnings: ["\u5185\u5BB9\u5168\u90E8\u662F\u4EE3\u7801\u3001\u94FE\u63A5\u6216\u5360\u4F4D\u7B26\uFF0C\u5DF2\u8DF3\u8FC7\u7FFB\u8BD1\u5E76\u4FDD\u6301\u539F\u6837\u3002"],
      restoredSlots: protectedCount,
      skipped: true,
      constraints: []
    };
  }
  const warnings = [];
  let providerId = "none";
  let totalLatency = 0;
  let detectedSourceLanguage;
  let untranslatedChunks = 0;
  const pieces = [];
  for (const segment of segments) {
    if (segment.kind === "protected") {
      pieces.push(segment.value);
      continue;
    }
    const { lead, core, trail } = splitEdges(segment.value);
    if (core === "" || !hasTranslatableChars(core)) {
      pieces.push(normalizePunctuation(segment.value, isEnglishTarget));
      continue;
    }
    const outcome = await translateChunk(core, options);
    providerId = outcome.providerId;
    totalLatency += outcome.latencyMs;
    if (detectedSourceLanguage === void 0 && outcome.detectedSourceLanguage !== void 0) {
      detectedSourceLanguage = outcome.detectedSourceLanguage;
    }
    if (outcome.text === "") {
      untranslatedChunks += 1;
      pieces.push(segment.value);
      continue;
    }
    pieces.push(`${lead}${normalizePunctuation(outcome.text, isEnglishTarget)}${trail}`);
  }
  if (untranslatedChunks > 0) {
    warnings.push(
      `\u6709 ${untranslatedChunks} \u6BB5\u6587\u5B57\u672A\u80FD\u7FFB\u8BD1\uFF0C\u5DF2\u4FDD\u7559\u539F\u6587\u7247\u6BB5\uFF1B\u8BF7\u5BF9\u7167\u539F\u6587\u624B\u52A8\u8865\u9F50\u3002`
    );
  }
  const translatedText = joinPieces(pieces, isEnglishTarget);
  const lost = masked.slots.filter((slot) => !translatedText.includes(slot.restoredAs));
  if (lost.length > 0) {
    throw new FormatIntegrityError(lost.map(previewOf));
  }
  const constraints = options.mode === "prompt" && hasCjk(text) && isEnglishTarget ? checkConstraints(text, translatedText) : [];
  warnings.push(...constraints.map((warning) => warning.message));
  return {
    translatedText,
    providerId,
    latencyMs: totalLatency,
    warnings,
    ...detectedSourceLanguage !== void 0 ? { detectedSourceLanguage } : {},
    restoredSlots: protectedCount,
    skipped: false,
    constraints
  };
}

// src/core/provider.ts
var SHORT_TEXT_CHARS = 120;
function computeTimeoutMs(text, configured) {
  const base = Number.isFinite(configured) && configured > 0 ? configured : 15e3;
  if (text.length <= SHORT_TEXT_CHARS) return Math.min(base, 8e3);
  const scaled = Math.round(base * Math.min(2, 1 + text.length / 2e3));
  return Math.max(8e3, Math.min(scaled, 3e4));
}
function timeoutSignal({ timeoutMs, signal }) {
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  const forwardAbort = () => controller.abort();
  if (signal !== void 0) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener("abort", forwardAbort, { once: true });
  }
  return {
    signal: controller.signal,
    cleanup: () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", forwardAbort);
    },
    didTimeout: () => timedOut
  };
}
function normalizeEndpoint(raw) {
  const trimmed = raw.trim().replace(/\/+$/, "");
  if (trimmed === "") return "http://127.0.0.1:5000";
  if (!/^https?:\/\//i.test(trimmed)) return `http://${trimmed}`;
  return trimmed;
}
var LibreTranslateProvider = class {
  id = "libretranslate-local";
  endpoint;
  timeoutMs;
  apiKey;
  fetchImpl;
  constructor(options) {
    this.endpoint = normalizeEndpoint(options.endpoint);
    this.timeoutMs = options.timeoutMs;
    this.apiKey = options.apiKey?.trim() || void 0;
    this.fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
  }
  async translate(request, signal) {
    const text = request.text;
    if (text.trim() === "") {
      throw new TranslationError("empty", "\u6CA1\u6709\u53EF\u7FFB\u8BD1\u7684\u5185\u5BB9\u3002");
    }
    const timeoutMs = computeTimeoutMs(text, this.timeoutMs);
    const started = performance.now();
    const guard = timeoutSignal({ timeoutMs, signal });
    try {
      const body = {
        q: text,
        source: request.sourceLanguage,
        target: request.targetLanguage,
        format: "text"
      };
      if (this.apiKey !== void 0) body["api_key"] = this.apiKey;
      const response = await this.fetchImpl(`${this.endpoint}/translate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
        signal: guard.signal
      });
      if (!response.ok) {
        const detail = await response.text().catch(() => "");
        throw new TranslationError(
          "http",
          `\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u8FD4\u56DE HTTP ${response.status}\u3002${httpHint(response.status)}`,
          { status: response.status, detail: detail.slice(0, 300) }
        );
      }
      const payload = await response.json().catch(() => null);
      if (payload === null || typeof payload !== "object") {
        throw new TranslationError("bad-response", "\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u8FD4\u56DE\u4E86\u65E0\u6CD5\u89E3\u6790\u7684\u54CD\u5E94\u3002");
      }
      const translated = payload.translatedText;
      if (typeof payload.error === "string" && payload.error.length > 0) {
        throw new TranslationError("bad-response", `\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u62A5\u9519\uFF1A${payload.error}`);
      }
      if (typeof translated !== "string") {
        throw new TranslationError("bad-response", "\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u54CD\u5E94\u7F3A\u5C11 translatedText \u5B57\u6BB5\u3002");
      }
      if (translated.trim() === "") {
        throw new TranslationError("empty", "\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u8FD4\u56DE\u4E86\u7A7A\u8BD1\u6587\uFF0C\u5DF2\u4FDD\u7559\u539F\u6587\u3002");
      }
      const language = payload.detectedLanguage?.language;
      const result = {
        translatedText: translated,
        providerId: this.id,
        latencyMs: Math.round(performance.now() - started)
      };
      if (typeof language === "string" && language !== "") {
        result.detectedSourceLanguage = language;
      }
      return result;
    } catch (error) {
      throw toTranslationError(error, guard.didTimeout(), timeoutMs);
    } finally {
      guard.cleanup();
    }
  }
  async health(signal) {
    const started = performance.now();
    const guard = timeoutSignal({ timeoutMs: 4e3, signal });
    try {
      const response = await this.fetchImpl(`${this.endpoint}/languages`, {
        method: "GET",
        signal: guard.signal
      });
      if (!response.ok) {
        throw new TranslationError("http", `\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u8FD4\u56DE HTTP ${response.status}\u3002`, {
          status: response.status
        });
      }
      const payload = await response.json().catch(() => null);
      const languages = parseLanguages(payload);
      const codes = new Set(languages.map((language) => language.code));
      const zhToEn = languages.some(
        (language) => ["zh", "zt"].includes(language.code) && language.targets.includes("en")
      );
      const enToZh = languages.some(
        (language) => language.code === "en" && language.targets.some((t) => t === "zh" || t === "zt")
      );
      return {
        ok: true,
        endpoint: this.endpoint,
        languages,
        hasChineseEnglishPair: zhToEn && enToZh && codes.has("en"),
        latencyMs: Math.round(performance.now() - started)
      };
    } catch (error) {
      const translated = toTranslationError(error, guard.didTimeout(), 4e3);
      return {
        ok: false,
        endpoint: this.endpoint,
        languages: [],
        hasChineseEnglishPair: false,
        latencyMs: Math.round(performance.now() - started),
        message: translated.userMessage
      };
    } finally {
      guard.cleanup();
    }
  }
};
function parseLanguages(payload) {
  if (!Array.isArray(payload)) return [];
  const languages = [];
  for (const entry of payload) {
    if (entry === null || typeof entry !== "object") continue;
    const record = entry;
    const code = record["code"];
    if (typeof code !== "string") continue;
    const targets = Array.isArray(record["targets"]) ? record["targets"].filter((value) => typeof value === "string") : [];
    languages.push({
      code,
      name: typeof record["name"] === "string" ? record["name"] : code,
      targets
    });
  }
  return languages;
}
function httpHint(status) {
  if (status === 400) return "\u901A\u5E38\u662F\u8BED\u8A00\u5BF9\u672A\u5B89\u88C5\uFF0C\u6216 source/target \u4E0D\u53D7\u652F\u6301\u3002";
  if (status === 429) return "\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u7A0D\u540E\u91CD\u8BD5\u3002";
  if (status >= 500) return "\u672C\u5730\u670D\u52A1\u5185\u90E8\u9519\u8BEF\uFF0C\u8BF7\u67E5\u770B\u670D\u52A1\u7AEF\u65E5\u5FD7\u3002";
  return "";
}
function toTranslationError(error, didTimeout, timeoutMs) {
  if (error instanceof TranslationError) return error;
  if (didTimeout) {
    return new TranslationError(
      "timeout",
      `\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\u5728 ${Math.round(timeoutMs / 1e3)} \u79D2\u5185\u6CA1\u6709\u54CD\u5E94\uFF0C\u5DF2\u4FDD\u7559\u539F\u6587\u3002`,
      { cause: error }
    );
  }
  if (error instanceof DOMException && error.name === "AbortError") {
    return new TranslationError("aborted", "\u7FFB\u8BD1\u5DF2\u53D6\u6D88\u3002", { cause: error });
  }
  const message = error instanceof Error ? error.message : String(error);
  const looksLikeConnectFailure = error instanceof TypeError || /failed to fetch|networkerror|econnrefused|connection refused/i.test(message);
  if (looksLikeConnectFailure) {
    return new TranslationError(
      "unreachable",
      "\u8FDE\u4E0D\u4E0A\u672C\u5730\u7FFB\u8BD1\u670D\u52A1\uFF08127.0.0.1\uFF09\u3002\u8BF7\u5148\u542F\u52A8\u672C\u5730\u670D\u52A1\uFF0C\u518D\u91CD\u8BD5\u3002",
      { cause: error }
    );
  }
  return new TranslationError("bad-response", `\u7FFB\u8BD1\u5931\u8D25\uFF1A${message}`, { cause: error });
}

// src/core/settings.ts
var DEFAULT_SETTINGS = {
  provider: "libretranslate-local",
  localEndpoint: "http://127.0.0.1:5000",
  sendTargetLanguage: "en",
  readingLanguage: "zh",
  chineseVariant: "simplified",
  inputMode: "manual",
  responseMode: "bilingual",
  autoTranslateResponse: true,
  preserveCode: true,
  preserveMarkdown: true,
  saveHistory: false,
  timeoutMs: 15e3,
  glossary: [],
  allowAutoSend: false
};
var SETTINGS_KEY = "linguabridge.settings.v1";
function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}
function normalizeSettings(raw) {
  const merged = { ...DEFAULT_SETTINGS };
  if (raw === null || typeof raw !== "object") return merged;
  const record = raw;
  const stringOr = (key, fallback) => {
    const value = record[key];
    return typeof value === "string" && value.trim() !== "" ? value : fallback;
  };
  merged.provider = stringOr("provider", DEFAULT_SETTINGS.provider);
  merged.localEndpoint = normalizeEndpoint(stringOr("localEndpoint", DEFAULT_SETTINGS.localEndpoint));
  merged.sendTargetLanguage = stringOr("sendTargetLanguage", DEFAULT_SETTINGS.sendTargetLanguage);
  merged.readingLanguage = stringOr("readingLanguage", DEFAULT_SETTINGS.readingLanguage);
  const variant = record["chineseVariant"];
  merged.chineseVariant = variant === "simplified" || variant === "traditional" || variant === "auto" ? variant : DEFAULT_SETTINGS.chineseVariant;
  merged.inputMode = record["inputMode"] === "auto" ? "auto" : "manual";
  merged.responseMode = record["responseMode"] === "off" ? "off" : "bilingual";
  for (const key of [
    "autoTranslateResponse",
    "preserveCode",
    "preserveMarkdown",
    "saveHistory",
    "allowAutoSend"
  ]) {
    const value = record[key];
    if (typeof value === "boolean") merged[key] = value;
  }
  merged.timeoutMs = clamp(Number(record["timeoutMs"] ?? DEFAULT_SETTINGS.timeoutMs), 3e3, 6e4);
  const glossary = record["glossary"];
  if (Array.isArray(glossary)) {
    merged.glossary = glossary.filter((entry) => {
      if (entry === null || typeof entry !== "object") return false;
      const source = entry.source;
      return typeof source === "string" && source.trim() !== "";
    }).map((entry) => ({
      source: entry.source.trim(),
      ...typeof entry.target === "string" && entry.target.trim() !== "" ? { target: entry.target.trim() } : {}
    })).slice(0, 200);
  }
  return merged;
}
function storageArea() {
  try {
    return chrome?.storage?.local ?? null;
  } catch {
    return null;
  }
}
var memoryFallback = null;
async function loadSettings() {
  const area = storageArea();
  if (area === null) return memoryFallback ?? { ...DEFAULT_SETTINGS };
  try {
    const stored = await area.get(SETTINGS_KEY);
    const value = stored[SETTINGS_KEY];
    return normalizeSettings(value);
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

// src/background/index.ts
var CONTEXT_MENU_ID = "lb-translate-selection";
function providerFor(settings) {
  return new LibreTranslateProvider({
    endpoint: settings.localEndpoint,
    timeoutMs: settings.timeoutMs
  });
}
async function handleTranslate(message) {
  const settings = await loadSettings();
  const provider = providerFor(settings);
  try {
    const outcome = await runPipeline({
      text: message.request.text,
      provider,
      targetLanguage: message.request.targetLanguage || settings.sendTargetLanguage,
      sourceLanguage: message.request.sourceLanguage,
      mode: message.request.mode,
      preserveCode: settings.preserveCode,
      glossary: message.glossary ?? settings.glossary,
      chineseVariant: settings.chineseVariant
    });
    return {
      ok: true,
      translatedText: outcome.translatedText,
      providerId: outcome.providerId,
      latencyMs: outcome.latencyMs,
      warnings: outcome.warnings,
      ...outcome.detectedSourceLanguage !== void 0 ? { detectedSourceLanguage: outcome.detectedSourceLanguage } : {},
      restoredSlots: outcome.restoredSlots,
      skipped: outcome.skipped
    };
  } catch (error) {
    if (error instanceof FormatIntegrityError) {
      const failure = {
        ok: false,
        kind: "format-integrity",
        message: error.message,
        invalidSlots: error.invalidSlots
      };
      return failure;
    }
    if (error instanceof TranslationError) {
      return { ok: false, kind: error.kind, message: error.userMessage };
    }
    const text = error instanceof Error ? error.message : String(error);
    return { ok: false, kind: "unknown", message: `\u7FFB\u8BD1\u5931\u8D25\uFF1A${text}` };
  }
}
async function handleHealth() {
  const settings = await loadSettings();
  const health = await providerFor(settings).health();
  return {
    ok: true,
    healthy: health.ok,
    endpoint: health.endpoint,
    latencyMs: health.latencyMs,
    hasChineseEnglishPair: health.hasChineseEnglishPair,
    languages: health.languages.map((language) => language.code),
    ...health.message !== void 0 ? { message: health.message } : {}
  };
}
async function refreshBadge() {
  const health = await handleHealth();
  const text = health.healthy ? "\u2713" : "!";
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color: health.healthy ? "#2f7d32" : "#b23a2f" });
  await chrome.action.setTitle({
    title: health.healthy ? `LinguaBridge \u5DF2\u8FDE\u63A5 ${health.endpoint}\uFF08${health.latencyMs}ms\uFF09` : `LinguaBridge\uFF1A\u8FDE\u4E0D\u4E0A ${health.endpoint}`
  });
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: CONTEXT_MENU_ID,
    title: "\u7528 LinguaBridge \u7FFB\u8BD1\u9009\u4E2D\u6587\u672C\uFF08\u672C\u5730\uFF09",
    contexts: ["selection"]
  });
  void refreshBadge();
});
chrome.runtime.onStartup?.addListener(() => {
  void refreshBadge();
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID || tab?.id === void 0) return;
  void chrome.tabs.sendMessage(tab.id, { type: "lb:command", command: "translate-selection" }).catch(() => {
  });
});
chrome.commands.onCommand.addListener((command) => {
  if (command !== "translate-prompt") return;
  void chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (tab?.id !== void 0) {
      return chrome.tabs.sendMessage(tab.id, { type: "lb:command", command: "translate-prompt" });
    }
    return void 0;
  }).catch(() => void 0);
});
chrome.action.onClicked.addListener(() => {
  void refreshBadge();
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  void (async () => {
    switch (message.type) {
      case "lb:translate":
        sendResponse(await handleTranslate(message));
        break;
      case "lb:health":
        sendResponse(await handleHealth());
        break;
      case "lb:ping":
        sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
        break;
      case "lb:command":
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, kind: "unknown", message: "\u672A\u77E5\u6D88\u606F\u7C7B\u578B\u3002" });
    }
  })();
  return true;
});
//# sourceMappingURL=background.js.map
