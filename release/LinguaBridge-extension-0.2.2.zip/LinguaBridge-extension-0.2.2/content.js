"use strict";
(() => {
  // src/core/messaging.ts
  async function sendRuntimeMessage(message) {
    try {
      const reply = await chrome.runtime.sendMessage(message);
      if (reply === void 0 || reply === null) {
        throw new Error("\u6269\u5C55\u540E\u53F0\u6CA1\u6709\u8FD4\u56DE\u7ED3\u679C\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u540E\u91CD\u8BD5\u3002");
      }
      return reply;
    } catch (error) {
      const text = error instanceof Error ? error.message : String(error);
      if (/Extension context invalidated|Receiving end does not exist|message port closed/i.test(text)) {
        throw new Error("\u6269\u5C55\u5DF2\u91CD\u65B0\u52A0\u8F7D\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u540E\u518D\u8BD5\u3002");
      }
      throw error;
    }
  }

  // src/core/provider.ts
  function normalizeEndpoint(raw) {
    const trimmed = raw.trim().replace(/\/+$/, "");
    if (trimmed === "") return "http://127.0.0.1:5000";
    if (!/^https?:\/\//i.test(trimmed)) return `http://${trimmed}`;
    return trimmed;
  }

  // src/core/settings.ts
  var DEFAULT_SETTINGS = {
    provider: "libretranslate-local",
    localEndpoint: "http://127.0.0.1:5000",
    sendTargetLanguage: "en",
    readingLanguage: "zh",
    chineseVariant: "simplified",
    inputMode: "manual",
    responseMode: "bilingual",
    autoTranslateResponse: true,
    preserveCode: true,
    preserveMarkdown: true,
    saveHistory: false,
    timeoutMs: 15e3,
    glossary: [],
    allowAutoSend: false
  };
  var SETTINGS_KEY = "linguabridge.settings.v1";
  function clamp(value, min, max) {
    if (!Number.isFinite(value)) return min;
    return Math.min(max, Math.max(min, Math.round(value)));
  }
  function normalizeSettings(raw) {
    const merged = { ...DEFAULT_SETTINGS };
    if (raw === null || typeof raw !== "object") return merged;
    const record = raw;
    const stringOr = (key, fallback) => {
      const value = record[key];
      return typeof value === "string" && value.trim() !== "" ? value : fallback;
    };
    merged.provider = stringOr("provider", DEFAULT_SETTINGS.provider);
    merged.localEndpoint = normalizeEndpoint(stringOr("localEndpoint", DEFAULT_SETTINGS.localEndpoint));
    merged.sendTargetLanguage = stringOr("sendTargetLanguage", DEFAULT_SETTINGS.sendTargetLanguage);
    merged.readingLanguage = stringOr("readingLanguage", DEFAULT_SETTINGS.readingLanguage);
    const variant = record["chineseVariant"];
    merged.chineseVariant = variant === "simplified" || variant === "traditional" || variant === "auto" ? variant : DEFAULT_SETTINGS.chineseVariant;
    merged.inputMode = record["inputMode"] === "auto" ? "auto" : "manual";
    merged.responseMode = record["responseMode"] === "off" ? "off" : "bilingual";
    for (const key of [
      "autoTranslateResponse",
      "preserveCode",
      "preserveMarkdown",
      "saveHistory",
      "allowAutoSend"
    ]) {
      const value = record[key];
      if (typeof value === "boolean") merged[key] = value;
    }
    merged.timeoutMs = clamp(Number(record["timeoutMs"] ?? DEFAULT_SETTINGS.timeoutMs), 3e3, 6e4);
    const glossary = record["glossary"];
    if (Array.isArray(glossary)) {
      merged.glossary = glossary.filter((entry) => {
        if (entry === null || typeof entry !== "object") return false;
        const source = entry.source;
        return typeof source === "string" && source.trim() !== "";
      }).map((entry) => ({
        source: entry.source.trim(),
        ...typeof entry.target === "string" && entry.target.trim() !== "" ? { target: entry.target.trim() } : {}
      })).slice(0, 200);
    }
    return merged;
  }
  function storageArea() {
    try {
      return chrome?.storage?.local ?? null;
    } catch {
      return null;
    }
  }
  var memoryFallback = null;
  async function loadSettings() {
    const area = storageArea();
    if (area === null) return memoryFallback ?? { ...DEFAULT_SETTINGS };
    try {
      const stored = await area.get(SETTINGS_KEY);
      const value = stored[SETTINGS_KEY];
      return normalizeSettings(value);
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  // src/content/ime.ts
  var COOLDOWN_MS = 60;
  var ImeGuard = class {
    attached = false;
    composing = false;
    endedAt = Number.NEGATIVE_INFINITY;
    doc;
    /** `doc` is optional so the module can be imported before a DOM exists (tests). */
    constructor(doc) {
      this.doc = doc;
    }
    attach() {
      if (this.attached) return this;
      const doc = this.doc ?? document;
      this.attached = true;
      const onStart = () => {
        this.composing = true;
      };
      const onEnd = () => {
        this.composing = false;
        this.endedAt = performance.now();
      };
      doc.addEventListener("compositionstart", onStart, true);
      doc.addEventListener("compositionend", onEnd, true);
      doc.addEventListener("blur", onEnd, true);
      return this;
    }
    get isComposing() {
      return this.composing;
    }
    /** True when it is safe to read or mutate the editor right now. */
    isSafe(cooldownMs = COOLDOWN_MS) {
      if (this.composing) return false;
      return performance.now() - this.endedAt > cooldownMs;
    }
  };
  var imeGuard = new ImeGuard();

  // src/content/text.ts
  var BLOCK_TAGS = /* @__PURE__ */ new Set([
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "DIV",
    "DL",
    "DT",
    "DD",
    "FIELDSET",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "FORM",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "HR",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "PRE",
    "SECTION",
    "TABLE",
    "TBODY",
    "TD",
    "TH",
    "THEAD",
    "TR",
    "UL"
  ]);
  var SKIP_TAGS = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "SVG", "TEMPLATE"]);
  function elementToText(root) {
    let output = "";
    const appendBreak = (count = 1) => {
      if (output.endsWith("\n")) return;
      output += "\n".repeat(count);
    };
    const walk = (node2) => {
      if (node2.nodeType === Node.TEXT_NODE) {
        output += node2.nodeValue ?? "";
        return;
      }
      if (!(node2 instanceof HTMLElement)) {
        node2.childNodes.forEach(walk);
        return;
      }
      const tag = node2.tagName;
      if (SKIP_TAGS.has(tag)) return;
      if (node2.hidden) return;
      if (node2.dataset["linguabridge"] !== void 0) return;
      if (node2.getAttribute("aria-hidden") === "true") return;
      if (tag === "BUTTON") return;
      if (tag === "BR") {
        output += "\n";
        return;
      }
      if (tag === "PRE") {
        appendBreak();
        output += (node2.textContent ?? "").replace(/\u00a0/g, " ");
        appendBreak();
        return;
      }
      const isBlock = BLOCK_TAGS.has(tag);
      if (isBlock) appendBreak();
      if (tag === "LI") {
        output += "- ";
      }
      node2.childNodes.forEach(walk);
      if (isBlock) appendBreak();
    };
    walk(root);
    return output.replace(/\u00a0/g, " ").split("\n").map((line) => line.replace(/[ \t]+$/g, "")).join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function selectedText() {
    const selection = window.getSelection();
    if (selection === null || selection.rangeCount === 0) return "";
    const anchor = selection.anchorNode;
    if (anchor !== null) {
      const element = anchor instanceof Element ? anchor : anchor.parentElement;
      if (element?.closest("[data-linguabridge]") !== null && element !== null) return "";
    }
    return selection.toString().trim();
  }

  // src/content/ui/panel.ts
  var BASE_CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  .panel {
    font: 13px/1.55 "Segoe UI", "Microsoft YaHei", system-ui, -apple-system, sans-serif;
    color: #1f2328;
    background: #ffffff;
    border: 1px solid rgba(15, 23, 42, 0.12);
    border-radius: 14px;
    box-shadow: 0 18px 48px rgba(15, 23, 42, 0.22), 0 2px 6px rgba(15, 23, 42, 0.08);
    display: flex;
    flex-direction: column;
    width: min(620px, calc(100vw - 32px));
    max-height: min(62vh, 560px);
    overflow: hidden;
  }
  .header {
    display: flex; align-items: center; gap: 8px;
    padding: 10px 12px 8px; border-bottom: 1px solid rgba(15, 23, 42, 0.08);
    background: linear-gradient(180deg, rgba(99, 102, 241, 0.08), transparent);
  }
  .title { font-weight: 600; font-size: 13px; letter-spacing: 0.01em; }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: #6366f1; }
  .meta { color: #667085; font-size: 11.5px; margin-left: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .spacer { flex: 1; }
  .icon-button {
    border: 0; background: transparent; cursor: pointer; color: #667085;
    font-size: 16px; line-height: 1; padding: 4px 6px; border-radius: 8px;
  }
  .icon-button:hover { background: rgba(15, 23, 42, 0.06); color: #1f2328; }
  .body { padding: 10px 12px; display: flex; flex-direction: column; gap: 10px; min-height: 0; overflow: auto; }
  .block { display: flex; flex-direction: column; gap: 4px; min-height: 0; }
  .label { font-size: 11px; font-weight: 600; color: #667085; letter-spacing: 0.04em; text-transform: uppercase; }
  .source {
    margin: 0; padding: 8px 10px; border-radius: 9px;
    background: rgba(15, 23, 42, 0.04); border: 1px solid rgba(15, 23, 42, 0.06);
    white-space: pre-wrap; word-break: break-word; max-height: 17vh; overflow: auto;
    font-family: inherit; user-select: text;
  }
  textarea.translation {
    width: 100%; min-height: 104px; resize: vertical; padding: 8px 10px;
    border-radius: 9px; border: 1px solid rgba(15, 23, 42, 0.16);
    font: inherit; line-height: 1.5; background: #fff; color: inherit;
    outline: none;
  }
  textarea.translation:focus { border-color: #6366f1; box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.16); }
  .status { font-size: 12px; color: #667085; min-height: 16px; }
  .status.error { color: #b42318; }
  .status.ok { color: #067647; }
  .warnings {
    border: 1px solid rgba(180, 83, 9, 0.28); background: rgba(254, 240, 199, 0.55);
    border-radius: 9px; padding: 7px 10px; color: #7a4b06; font-size: 12px;
  }
  .warnings summary { cursor: pointer; font-weight: 600; }
  .warnings ul { margin: 6px 0 0; padding-left: 18px; }
  .warnings li { margin: 2px 0; }
  .footer {
    display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
    padding: 10px 12px; border-top: 1px solid rgba(15, 23, 42, 0.08);
    background: rgba(15, 23, 42, 0.02);
  }
  button.action {
    font: inherit; font-size: 12.5px; padding: 6px 12px; border-radius: 8px; cursor: pointer;
    border: 1px solid rgba(15, 23, 42, 0.16); background: #fff; color: #1f2328;
  }
  button.action:hover:not(:disabled) { background: rgba(15, 23, 42, 0.05); }
  button.action:disabled { opacity: 0.5; cursor: not-allowed; }
  button.primary { background: #4f46e5; border-color: #4f46e5; color: #fff; font-weight: 600; }
  button.primary:hover:not(:disabled) { background: #4338ca; }
  button.send { background: #0f766e; border-color: #0f766e; color: #fff; }
  button.send:hover:not(:disabled) { background: #115e59; }
  .hint { font-size: 11px; color: #98a2b3; margin-left: auto; }
  @media (prefers-color-scheme: dark) {
    .panel { background: #16181d; color: #e6e6e6; border-color: rgba(255,255,255,0.12); }
    .header { border-bottom-color: rgba(255,255,255,0.08); background: linear-gradient(180deg, rgba(99,102,241,0.18), transparent); }
    .meta, .label, .status { color: #9aa4b2; }
    .source { background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.08); }
    textarea.translation { background: #101216; border-color: rgba(255,255,255,0.16); color: #e6e6e6; }
    button.action { background: #1d2027; border-color: rgba(255,255,255,0.16); color: #e6e6e6; }
    button.action:hover:not(:disabled) { background: #242832; }
    button.primary { background: #6366f1; border-color: #6366f1; color: #fff; }
    button.send { background: #0f766e; border-color: #0f766e; color: #fff; }
    .warnings { background: rgba(120, 72, 12, 0.35); border-color: rgba(217, 119, 6, 0.45); color: #f4c97a; }
    .footer { background: rgba(255,255,255,0.03); border-top-color: rgba(255,255,255,0.08); }
  }
`;
  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className !== void 0) element.className = className;
    if (text !== void 0) element.textContent = text;
    return element;
  }
  var ComparePanel = class {
    host = null;
    root = null;
    handlers;
    sourceEl = null;
    translationEl = null;
    statusEl = null;
    warningsEl = null;
    warningsList = null;
    metaEl = null;
    buttons = [];
    writeButton = null;
    sendButton = null;
    constructor(handlers) {
      this.handlers = handlers;
    }
    get isOpen() {
      return this.host !== null && this.host.isConnected;
    }
    getTranslation() {
      return this.translationEl?.value ?? "";
    }
    open() {
      if (this.host !== null) {
        this.host.style.display = "block";
        return;
      }
      const host = document.createElement("div");
      host.dataset["linguabridge"] = "panel";
      host.style.cssText = "position:fixed;left:50%;transform:translateX(-50%);bottom:132px;z-index:2147483000;display:block;";
      for (const type of ["keydown", "keyup", "keypress", "pointerdown", "mousedown", "click"]) {
        host.addEventListener(type, (event) => event.stopPropagation());
      }
      const root = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = BASE_CSS;
      const panel2 = node("div", "panel");
      const header = node("div", "header");
      header.append(node("span", "dot"), node("span", "title", "LinguaBridge"));
      const meta = node("span", "meta", "");
      meta.setAttribute("aria-live", "polite");
      header.append(meta, node("span", "spacer"));
      const close = node("button", "icon-button", "\xD7");
      close.title = "\u5173\u95ED\uFF08Esc\uFF09";
      close.setAttribute("aria-label", "\u5173\u95ED");
      close.addEventListener("click", () => this.handlers.onClose());
      header.append(close);
      const body = node("div", "body");
      const sourceBlock = node("div", "block");
      sourceBlock.append(node("div", "label", "\u539F\u6587"));
      const source = node("pre", "source");
      sourceBlock.append(source);
      const translationBlock = node("div", "block");
      translationBlock.append(node("div", "label", "\u8BD1\u6587\uFF08\u53EF\u7F16\u8F91\uFF09"));
      const translation = node("textarea", "translation");
      translation.spellcheck = false;
      translation.setAttribute("aria-label", "\u8BD1\u6587");
      translation.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && !event.shiftKey) event.stopPropagation();
      });
      translationBlock.append(translation);
      const status = node("div", "status");
      status.setAttribute("role", "status");
      const warnings = document.createElement("details");
      warnings.className = "warnings";
      const summary = document.createElement("summary");
      warnings.append(summary);
      const warningList = node("ul");
      warnings.append(warningList);
      warnings.style.display = "none";
      body.append(sourceBlock, translationBlock, warnings, status);
      const footer = node("div", "footer");
      const copy = node("button", "action", "\u590D\u5236\u8BD1\u6587");
      copy.addEventListener("click", () => {
        void this.copyTranslation();
      });
      const retry = node("button", "action", "\u91CD\u8BD1");
      retry.addEventListener("click", () => this.handlers.onRetranslate());
      const write = node("button", "action primary", "\u5199\u5165\u8F93\u5165\u6846");
      write.addEventListener("click", () => this.handlers.onWrite(this.getTranslation()));
      const writeAndSend = node("button", "action send", "\u5199\u5165\u5E76\u53D1\u9001");
      writeAndSend.addEventListener("click", () => this.handlers.onWriteAndSend(this.getTranslation()));
      const hint = node("span", "hint", "Esc \u5173\u95ED \xB7 \u5199\u5165\u524D\u8BF7\u6838\u5BF9");
      footer.append(copy, retry, write, writeAndSend, hint);
      panel2.append(header, body, footer);
      root.append(style, panel2);
      document.documentElement.append(host);
      host.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
          event.stopPropagation();
          this.handlers.onClose();
        }
      });
      this.host = host;
      this.root = root;
      this.sourceEl = source;
      this.translationEl = translation;
      this.statusEl = status;
      this.warningsEl = warnings;
      this.warningsList = warningList;
      this.metaEl = meta;
      this.buttons = [copy, retry, write, writeAndSend];
      this.writeButton = write;
      this.sendButton = writeAndSend;
    }
    render(view) {
      this.open();
      if (this.sourceEl !== null) this.sourceEl.textContent = view.source;
      if (this.translationEl !== null && this.translationEl.value !== view.translation) {
        this.translationEl.value = view.translation;
      }
      if (this.metaEl !== null) this.metaEl.textContent = view.meta ?? "";
      if (this.warningsEl !== null && this.warningsList !== null) {
        this.warningsList.replaceChildren();
        for (const warning of view.warnings) {
          this.warningsList.append(node("li", void 0, warning));
        }
        const visible = view.warnings.length > 0;
        this.warningsEl.style.display = visible ? "block" : "none";
        this.warningsEl.open = visible;
        const summary = this.warningsEl.querySelector("summary");
        if (summary !== null) summary.textContent = `\u6CE8\u610F\u4E8B\u9879\uFF08${view.warnings.length}\uFF09\u2014 \u5EFA\u8BAE\u9010\u53E5\u6838\u5BF9`;
      }
      const busy = view.busy === true;
      for (const button of this.buttons) button.disabled = busy;
      if (this.writeButton !== null) this.writeButton.disabled = busy || view.translation.trim() === "";
      if (this.sendButton !== null) this.sendButton.disabled = busy || view.translation.trim() === "";
      this.setStatus(view.error ?? (busy ? "\u6B63\u5728\u8BF7\u6C42\u672C\u5730\u7FFB\u8BD1\u2026" : ""), view.error !== void 0 ? "error" : "info");
    }
    setStatus(message, kind = "info") {
      if (this.statusEl === null) return;
      this.statusEl.textContent = message;
      this.statusEl.className = `status ${kind === "info" ? "" : kind}`.trim();
    }
    /** Called by the controller after a write attempt, so the panel stays honest. */
    setOutcome(message, kind) {
      this.setStatus(message, kind);
    }
    close() {
      if (this.host !== null) {
        this.host.remove();
        this.host = null;
        this.root = null;
        this.sourceEl = null;
        this.translationEl = null;
        this.statusEl = null;
        this.warningsEl = null;
        this.warningsList = null;
        this.metaEl = null;
        this.buttons = [];
        this.writeButton = null;
        this.sendButton = null;
      }
    }
    async copyTranslation() {
      const text = this.getTranslation();
      if (text === "") return;
      try {
        await navigator.clipboard.writeText(text);
        this.setStatus("\u8BD1\u6587\u5DF2\u590D\u5236\u3002", "ok");
      } catch {
        const scratch = document.createElement("textarea");
        scratch.value = text;
        document.body.append(scratch);
        scratch.select();
        try {
          document.execCommand("copy");
          this.setStatus("\u8BD1\u6587\u5DF2\u590D\u5236\u3002", "ok");
        } catch {
          this.setStatus("\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u9009\u4E2D\u8BD1\u6587\u3002", "error");
        } finally {
          scratch.remove();
        }
      }
    }
  };
  function createLauncher(onClick) {
    const host = document.createElement("div");
    host.dataset["linguabridge"] = "launcher";
    host.style.cssText = "position:fixed;right:18px;bottom:88px;z-index:2147483000;";
    const root = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    :host { all: initial; }
    button {
      font: 600 12px/1 "Segoe UI", "Microsoft YaHei", system-ui, sans-serif;
      width: 38px; height: 38px; border-radius: 50%; cursor: pointer;
      border: 1px solid rgba(15, 23, 42, 0.12);
      background: #ffffff; color: #4f46e5;
      box-shadow: 0 6px 18px rgba(15, 23, 42, 0.18);
      display: grid; place-items: center;
    }
    button:hover { background: #eef2ff; }
    @media (prefers-color-scheme: dark) {
      button { background: #1d2027; color: #a5b4fc; border-color: rgba(255,255,255,0.16); }
      button:hover { background: #262b36; }
    }
  `;
    const button = document.createElement("button");
    button.textContent = "\u8BD1";
    button.title = "LinguaBridge\uFF1A\u7FFB\u8BD1\u8F93\u5165\u6846\uFF08Ctrl+Alt+T\uFF09";
    button.setAttribute("aria-label", "\u7FFB\u8BD1\u8F93\u5165\u6846");
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      onClick();
    });
    root.append(style, button);
    return host;
  }
  function createReplyCard(options) {
    const host = document.createElement("div");
    host.dataset["linguabridge"] = "reply";
    const root = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    :host { all: initial; }
    .card {
      font: 13px/1.6 "Segoe UI", "Microsoft YaHei", system-ui, sans-serif;
      color: #1f2328; background: rgba(99, 102, 241, 0.06);
      border: 1px solid rgba(99, 102, 241, 0.25);
      border-left: 3px solid #6366f1;
      border-radius: 10px; margin: 10px 0; padding: 8px 12px;
    }
    .head { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: #5b5fc7; font-weight: 600; }
    .spacer { flex: 1; }
    .text { margin-top: 6px; white-space: pre-wrap; word-break: break-word; user-select: text; }
    .text.collapsed { display: none; }
    button { font: inherit; font-size: 11.5px; border: 0; background: transparent; color: #5b5fc7; cursor: pointer; padding: 2px 6px; border-radius: 6px; }
    button:hover { background: rgba(99, 102, 241, 0.12); }
    .warn { margin-top: 6px; font-size: 11.5px; color: #92400e; }
    @media (prefers-color-scheme: dark) {
      .card { background: rgba(99, 102, 241, 0.12); border-color: rgba(129, 140, 248, 0.35); color: #e6e6e6; }
      .head, button { color: #a5b4fc; }
      .warn { color: #fbbf24; }
    }
  `;
    const card = document.createElement("div");
    card.className = "card";
    const head = document.createElement("div");
    head.className = "head";
    head.append(document.createTextNode("\u672C\u5730\u8BD1\u6587"));
    const meta = document.createElement("span");
    meta.textContent = ` \xB7 ${options.meta}`;
    meta.style.fontWeight = "400";
    head.append(meta, document.createElement("span"));
    head.lastElementChild?.setAttribute("class", "spacer");
    const collapse = document.createElement("button");
    collapse.textContent = "\u6536\u8D77";
    const copy = document.createElement("button");
    copy.textContent = "\u590D\u5236";
    const text = document.createElement("div");
    text.className = "text";
    text.textContent = options.translatedText;
    collapse.addEventListener("click", () => {
      const collapsed = text.classList.toggle("collapsed");
      collapse.textContent = collapsed ? "\u5C55\u5F00" : "\u6536\u8D77";
    });
    copy.addEventListener("click", () => {
      void navigator.clipboard.writeText(options.translatedText).catch(() => {
      });
      copy.textContent = "\u5DF2\u590D\u5236";
      setTimeout(() => {
        copy.textContent = "\u590D\u5236";
      }, 1200);
    });
    head.append(collapse, copy);
    card.append(head, text);
    if (options.warnings.length > 0) {
      const warn = document.createElement("div");
      warn.className = "warn";
      warn.textContent = `\u26A0 ${options.warnings.length} \u6761\u6CE8\u610F\u4E8B\u9879\uFF08\u53EF\u80FD\u5F71\u54CD\u8BED\u4E49\uFF0C\u8BF7\u5BF9\u7167\u539F\u6587\uFF09`;
      card.append(warn);
    }
    root.append(style, card);
    return host;
  }

  // src/content/dom.ts
  function isVisible(element) {
    if (!(element instanceof HTMLElement)) return false;
    if (element.hidden) return false;
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function normalizeEditorText(value) {
    return value.replace(/\u00a0/g, " ").replace(/\r\n?/g, "\n").split("\n").map((line) => line.replace(/[ \t]+$/g, "")).join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function readEditable(element) {
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      return element.value;
    }
    return element.innerText ?? element.textContent ?? "";
  }
  function selectAllContents(element) {
    const selection = window.getSelection();
    if (selection === null) return false;
    const range = document.createRange();
    range.selectNodeContents(element);
    selection.removeAllRanges();
    selection.addRange(range);
    return true;
  }
  function setNativeValue(element, value) {
    const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (descriptor?.set !== void 0) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }
    element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  }
  function insertViaExecCommand(text) {
    try {
      return document.execCommand("insertText", false, text);
    } catch {
      return false;
    }
  }
  function insertLineByLine(text) {
    const lines = text.split("\n");
    lines.forEach((line, index) => {
      if (index > 0) {
        try {
          document.execCommand("insertLineBreak");
        } catch {
          insertViaExecCommand("\n");
        }
      }
      if (line !== "") insertViaExecCommand(line);
    });
  }
  function replaceWithTextContent(element, text) {
    element.textContent = text;
    element.dispatchEvent(
      new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: text })
    );
  }
  function writeToEditable(element, text) {
    element.focus({ preventScroll: false });
    const expected = normalizeEditorText(text);
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      selectAllContents(element);
      setNativeValue(element, text);
      const actual2 = normalizeEditorText(readEditable(element));
      return {
        ok: actual2 === expected,
        method: "nativeSetter",
        actual: actual2,
        ...actual2 === expected ? {} : { reason: "\u9875\u9762\u8F93\u5165\u6846\u6CA1\u6709\u63A5\u53D7\u5199\u5165\u7684\u6587\u672C\u3002" }
      };
    }
    if (selectAllContents(element)) {
      try {
        document.execCommand("delete");
      } catch {
      }
      if (insertViaExecCommand(text)) {
        const actual2 = normalizeEditorText(readEditable(element));
        if (actual2 === expected) return { ok: true, method: "execCommand", actual: actual2 };
      }
    }
    if (text.includes("\n") && selectAllContents(element)) {
      try {
        document.execCommand("delete");
      } catch {
      }
      insertLineByLine(text);
      const actual2 = normalizeEditorText(readEditable(element));
      if (actual2 === expected) return { ok: true, method: "lineBreaks", actual: actual2 };
    }
    replaceWithTextContent(element, text);
    const actual = normalizeEditorText(readEditable(element));
    return {
      ok: actual === expected,
      method: "fallback-dom",
      actual,
      ...actual === expected ? {} : { reason: "\u7F16\u8F91\u5668\u672A\u63A5\u53D7\u5199\u5165\uFF08DOM \u4E0E\u5185\u90E8\u72B6\u6001\u4E0D\u540C\u6B65\uFF09\uFF0C\u8BF7\u624B\u52A8\u7C98\u8D34\u8BD1\u6587\u3002" }
    };
  }
  function pressEnter(element, options = {}) {
    const shift = options.shift === true;
    const init = {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true,
      composed: true,
      shiftKey: shift
    };
    element.dispatchEvent(new KeyboardEvent("keydown", init));
    element.dispatchEvent(new KeyboardEvent("keypress", init));
    element.dispatchEvent(new KeyboardEvent("keyup", init));
  }

  // src/content/sites/chatgpt.ts
  var INPUT_SELECTORS = [
    "#prompt-textarea",
    'form [contenteditable="true"]',
    'main [contenteditable="true"]',
    "textarea[placeholder]"
  ];
  var ASSISTANT_SELECTOR = '[data-message-author-role="assistant"]';
  function firstVisible(selectors, root = document) {
    for (const selector of selectors) {
      for (const element of root.querySelectorAll(selector)) {
        if (isVisible(element)) return element;
      }
    }
    return null;
  }
  var ChatGptAdapter = class {
    id = "chatgpt";
    label = "ChatGPT";
    cachedInput = null;
    match(url) {
      return url.hostname === "chatgpt.com" || url.hostname === "chat.openai.com";
    }
    getInputElement() {
      if (this.cachedInput !== null && this.cachedInput.isConnected && isVisible(this.cachedInput)) {
        return this.cachedInput;
      }
      this.cachedInput = firstVisible(INPUT_SELECTORS);
      return this.cachedInput;
    }
    readInput() {
      const input = this.getInputElement();
      return input === null ? "" : normalizeEditorText(readEditable(input));
    }
    writeInput(text) {
      const input = this.getInputElement();
      if (input === null) {
        return { ok: false, method: "none", actual: "", reason: "\u627E\u4E0D\u5230 ChatGPT \u8F93\u5165\u6846\uFF0C\u8BF7\u5148\u70B9\u4E00\u4E0B\u8F93\u5165\u6846\u518D\u8BD5\u3002" };
      }
      return writeToEditable(input, text);
    }
    send() {
      const button = document.querySelector('[data-testid="send-button"]') ?? document.querySelector('button[aria-label*="Send" i]') ?? document.querySelector('button[aria-label*="\u53D1\u9001"]');
      if (button !== null && !button.hasAttribute("disabled")) {
        button.click();
        return true;
      }
      const input = this.getInputElement();
      if (input !== null) {
        pressEnter(input);
        return true;
      }
      return false;
    }
    getLatestResponse() {
      const nodes = [...document.querySelectorAll(ASSISTANT_SELECTOR)].filter(isVisible);
      const last = nodes[nodes.length - 1];
      if (last === void 0) return null;
      const text = elementToText(last);
      if (text.length < 8) return null;
      const key = last.getAttribute("data-message-id") ?? `hash:${text.length}:${text.slice(0, 64)}`;
      return { key, text, anchor: last };
    }
    insertResponseCard(target, card) {
      const anchor = target.anchor.isConnected ? target.anchor : null;
      if (anchor === null) return;
      const article = anchor.closest("article");
      (article ?? anchor).insertAdjacentElement("afterend", card);
    }
    observeResponses(callback) {
      const root = document.querySelector("main") ?? document.body;
      let timer;
      const observer = new MutationObserver(() => {
        if (timer !== void 0) window.clearTimeout(timer);
        timer = window.setTimeout(callback, 900);
      });
      observer.observe(root, { childList: true, subtree: true, characterData: true });
      return () => {
        if (timer !== void 0) window.clearTimeout(timer);
        observer.disconnect();
      };
    }
  };

  // src/content/sites/dsh.ts
  var INPUT_SELECTORS2 = [
    '[data-composer-seat] [data-lexical-editor="true"]',
    '[data-composer-card] [data-lexical-editor="true"]',
    '[data-composer-seat] [contenteditable="true"]',
    '[data-lexical-editor="true"]',
    "[data-composer-seat] textarea"
  ];
  var SCROLL_SELECTORS = ["[data-conversation-scroll]", "[data-chat-anchor-key]"];
  var SEND_LABELS = ["send", "\u53D1\u9001", "\u63D0\u4EA4", "submit"];
  var NON_ASSISTANT_ROW_SELECTORS = [
    '[data-slot="conversation.chat.user.content"]',
    "[data-submission-echo]",
    "[data-turn-tail]",
    '[data-chat-flow-kind="turn-tail"]',
    "[data-goal-bar]",
    "[data-terminal]"
  ];
  var PROSE_SELECTORS = '[class*="_markdown"], [data-markdown-variant], pre, blockquote, table';
  var EXCLUDED_SUBTREES = [
    "button",
    '[role="toolbar"]',
    "[data-chat-call-id]",
    '[data-slot^="conversation.chat.reasoning"]',
    '[data-slot^="conversation.trajectory"]',
    '[data-slot="conversation.chat.assistant-actions"]',
    "script",
    "style",
    "svg",
    '[aria-hidden="true"]',
    "[data-linguabridge]"
  ].join(", ");
  function firstVisible2(selectors, root = document) {
    for (const selector of selectors) {
      for (const element of root.querySelectorAll(selector)) {
        if (isVisible(element)) return element;
      }
    }
    return null;
  }
  function findSendButton(composer) {
    const scope = composer?.closest("[data-composer-card]") ?? document;
    const submit = scope.querySelector('button[type="submit"]');
    if (submit !== null && !submit.hasAttribute("disabled")) return submit;
    for (const button of scope.querySelectorAll("button")) {
      const label = `${button.getAttribute("aria-label") ?? ""} ${button.getAttribute("title") ?? ""} ${button.textContent ?? ""}`.toLowerCase();
      if (SEND_LABELS.some((candidate) => label.includes(candidate)) && !button.hasAttribute("disabled")) {
        return button;
      }
    }
    return null;
  }
  var DshAdapter = class {
    id = "dsh";
    label = "DeepSeek Harness";
    cachedInput = null;
    match(_url) {
      return document.querySelector("[data-composer-seat]") !== null || document.querySelector('[data-lexical-editor="true"]') !== null || document.querySelector("[data-conversation-scroll]") !== null;
    }
    getInputElement() {
      if (this.cachedInput !== null && this.cachedInput.isConnected && isVisible(this.cachedInput)) {
        return this.cachedInput;
      }
      this.cachedInput = firstVisible2(INPUT_SELECTORS2);
      return this.cachedInput;
    }
    readInput() {
      const input = this.getInputElement();
      if (input === null) return "";
      return normalizeEditorText(readEditable(input));
    }
    writeInput(text) {
      const input = this.getInputElement();
      if (input === null) {
        return { ok: false, method: "none", actual: "", reason: "\u627E\u4E0D\u5230 DSH \u8F93\u5165\u6846\uFF0C\u8BF7\u5148\u70B9\u4E00\u4E0B\u8F93\u5165\u6846\u518D\u8BD5\u3002" };
      }
      return writeToEditable(input, text);
    }
    send() {
      const input = this.getInputElement();
      const button = findSendButton(input);
      if (button !== null) {
        button.click();
        return true;
      }
      if (input !== null) {
        pressEnter(input);
        return true;
      }
      return false;
    }
    /** Transcript rows, newest last, with non-assistant rows already removed. */
    assistantRows() {
      const scroller = document.querySelector(SCROLL_SELECTORS[0] ?? "") ?? document.body;
      const input = this.getInputElement();
      return [...scroller.querySelectorAll("[data-chat-anchor-key]")].filter((row) => {
        if (!isVisible(row)) return false;
        if (input !== null && row.contains(input)) return false;
        if (row.closest("[data-composer-seat]") !== null) return false;
        for (const selector of NON_ASSISTANT_ROW_SELECTORS) {
          if (row.querySelector(selector) !== null) return false;
        }
        return true;
      });
    }
    getLatestResponse() {
      const rows = this.assistantRows();
      const candidates = [];
      for (const row of rows) {
        const text = this.extractRowText(row);
        if (text.length < 8) continue;
        candidates.push({ row, text, prose: row.querySelector(PROSE_SELECTORS) !== null });
      }
      if (candidates.length === 0) return null;
      const proseCandidates = candidates.filter((candidate) => candidate.prose);
      const chosen = proseCandidates[proseCandidates.length - 1] ?? candidates[candidates.length - 1];
      if (chosen === void 0) return null;
      return { key: this.rowKey(chosen.row, chosen.text), text: chosen.text, anchor: chosen.row };
    }
    rowKey(row, text) {
      const nodeKey = row.dataset["chatNodeKey"];
      if (nodeKey !== void 0 && nodeKey !== "") return `node:${nodeKey}`;
      const anchorKey = row.dataset["chatAnchorKey"];
      if (anchorKey !== void 0 && anchorKey !== "") return `anchor:${anchorKey}`;
      let hash = 0;
      for (let index = 0; index < text.length; index += 1) {
        hash = hash * 31 + text.charCodeAt(index) | 0;
      }
      return `hash:${hash.toString(36)}`;
    }
    /**
     * Reply text for one row: drop tool calls, thinking, execution trace, action
     * bars and our own cards; keep prose and code fences.
     */
    extractRowText(row) {
      const clone = row.cloneNode(true);
      for (const junk of clone.querySelectorAll(EXCLUDED_SUBTREES)) junk.remove();
      return elementToText(clone);
    }
    insertResponseCard(target, card) {
      const anchor = target.anchor.isConnected ? target.anchor : null;
      if (anchor === null) return;
      anchor.insertAdjacentElement("afterend", card);
    }
    observeResponses(callback) {
      const scroller = document.querySelector(SCROLL_SELECTORS[0] ?? "");
      if (scroller === null) return () => {
      };
      let timer;
      const observer = new MutationObserver(() => {
        if (timer !== void 0) window.clearTimeout(timer);
        timer = window.setTimeout(callback, 900);
      });
      observer.observe(scroller, { childList: true, subtree: true, characterData: true });
      return () => {
        if (timer !== void 0) window.clearTimeout(timer);
        observer.disconnect();
      };
    }
  };

  // src/content/index.ts
  var START_HINT = "\u542F\u52A8\u65B9\u6CD5\uFF1A\u5728\u9879\u76EE\u76EE\u5F55\u8FD0\u884C tools\\start-engine.ps1\uFF08\u6216 libretranslate --host 127.0.0.1 --port 5000 --load-only en,zh\uFF09\u3002";
  var settings;
  var adapter = null;
  var panel;
  var launcher = null;
  var lastWrittenText = "";
  var currentSource = { text: "", mode: "prompt" };
  var extensionVersion = "";
  var translatedReplyKeys = /* @__PURE__ */ new Set();
  var replyCards = /* @__PURE__ */ new Map();
  var settleTimer;
  var stopObserving = null;
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function isMostlyCjk(text) {
    const cjk = text.match(/[\u3400-\u4dbf\u4e00-\u9fff]/g)?.length ?? 0;
    const letters = text.match(/[A-Za-z]/g)?.length ?? 0;
    return cjk > letters;
  }
  function failureHint(reply) {
    if (reply.kind === "unreachable" || reply.kind === "timeout") {
      return `${reply.message}
${START_HINT}`;
    }
    if (reply.kind === "format-integrity") {
      return `${reply.message}
\u8BF4\u660E\uFF1A\u8BD1\u6587\u91CC\u7F3A\u5C11\u53D7\u4FDD\u62A4\u7684\u4EE3\u7801/\u94FE\u63A5\u7247\u6BB5\uFF0C\u4E3A\u907F\u514D\u7834\u574F\u63D0\u793A\u8BCD\u5DF2\u62D2\u7EDD\u5199\u5165\u3002`;
    }
    return reply.message;
  }
  async function showFailure(message, sourceText) {
    panel.render({ source: sourceText, translation: "", warnings: [], error: message });
  }
  async function translateText(text, mode) {
    if (!imeGuard.isSafe()) {
      panel.render({
        source: text,
        translation: "",
        warnings: [],
        error: "\u8F93\u5165\u6CD5\u6B63\u5728\u7EC4\u5408\u4E2D\uFF0C\u5DF2\u6682\u505C\u7FFB\u8BD1\u3002\u8BF7\u5148\u5B8C\u6210\u672C\u6B21\u8F93\u5165\uFF08\u6309\u7A7A\u683C/\u56DE\u8F66\u786E\u8BA4\u5019\u9009\u8BCD\uFF09\u518D\u8BD5\u3002"
      });
      return;
    }
    if (text.trim() === "") {
      panel.render({ source: "", translation: "", warnings: [], error: "\u8F93\u5165\u6846\u662F\u7A7A\u7684\uFF0C\u5148\u5199\u70B9\u5185\u5BB9\u518D\u7FFB\u8BD1\u3002" });
      return;
    }
    currentSource = { text, mode };
    panel.render({ source: text, translation: "", warnings: [], busy: true });
    try {
      const reply = await sendRuntimeMessage({
        type: "lb:translate",
        request: {
          text,
          sourceLanguage: "auto",
          targetLanguage: settings.sendTargetLanguage,
          mode: mode === "prompt" ? "prompt" : "plain"
        }
      });
      if (!reply.ok) {
        await showFailure(failureHint(reply), text);
        return;
      }
      const meta = [
        reply.providerId,
        `${(reply.latencyMs / 1e3).toFixed(1)}s`,
        reply.restoredSlots > 0 ? `\u5DF2\u8FD8\u539F ${reply.restoredSlots} \u5904\u4EE3\u7801/\u94FE\u63A5` : "\u65E0\u53D7\u4FDD\u62A4\u683C\u5F0F",
        reply.detectedSourceLanguage !== void 0 ? `\u68C0\u6D4B\u8BED\u8A00 ${reply.detectedSourceLanguage}` : "",
        extensionVersion !== "" ? `v${extensionVersion}` : ""
      ].filter((part) => part !== "").join(" \xB7 ");
      panel.render({
        source: text,
        translation: reply.translatedText,
        warnings: reply.warnings,
        meta,
        busy: false
      });
    } catch (error) {
      await showFailure(error instanceof Error ? error.message : String(error), text);
    }
  }
  async function translatePrompt() {
    if (adapter === null) return;
    if (!imeGuard.isSafe()) {
      panel.render({
        source: adapter.readInput(),
        translation: "",
        warnings: [],
        error: "\u8F93\u5165\u6CD5\u6B63\u5728\u7EC4\u5408\u4E2D\uFF0C\u6682\u65F6\u4E0D\u80FD\u64CD\u4F5C\u8F93\u5165\u6846\u3002"
      });
      return;
    }
    const text = adapter.readInput();
    await translateText(text, "prompt");
  }
  async function translateSelection() {
    const text = selectedText();
    if (text === "") {
      panel.render({ source: "", translation: "", warnings: [], error: "\u6CA1\u6709\u9009\u4E2D\u6587\u672C\u3002\u5148\u9009\u4E2D\u4E00\u6BB5\u5185\u5BB9\u518D\u70B9\u53F3\u952E\u83DC\u5355\u3002" });
      return;
    }
    await translateText(text, "selection");
  }
  function writeToInput(text) {
    if (adapter === null) return false;
    if (!imeGuard.isSafe()) {
      panel.setOutcome("\u8F93\u5165\u6CD5\u6B63\u5728\u7EC4\u5408\u4E2D\uFF0C\u672A\u5199\u5165\u3002\u8BF7\u5B8C\u6210\u8F93\u5165\u540E\u518D\u8BD5\u3002", "error");
      return false;
    }
    const result = adapter.writeInput(text);
    if (!result.ok) {
      panel.setOutcome(`${result.reason ?? "\u5199\u5165\u5931\u8D25\uFF08\u9875\u9762\u6CA1\u6709\u63A5\u53D7\u6587\u672C\uFF09\u3002"}`, "error");
      return false;
    }
    lastWrittenText = text;
    return true;
  }
  function wirePanel() {
    panel = new ComparePanel({
      onRetranslate: () => {
        void translateText(currentSource.text, currentSource.mode);
      },
      onWrite: (text) => {
        if (writeToInput(text)) {
          panel.setOutcome("\u5DF2\u5199\u5165\u8F93\u5165\u6846\u3002\u8BF7\u6838\u5BF9\u540E\u6309 Enter \u53D1\u9001\uFF08\u672C\u6269\u5C55\u4E0D\u4F1A\u81EA\u52A8\u53D1\u9001\uFF09\u3002", "ok");
        }
      },
      onWriteAndSend: (text) => {
        if (!writeToInput(text)) return;
        const sent = adapter?.send() ?? false;
        panel.setOutcome(sent ? "\u5DF2\u5199\u5165\u5E76\u89E6\u53D1\u53D1\u9001\u3002" : "\u5DF2\u5199\u5165\uFF0C\u4F46\u6CA1\u6709\u627E\u5230\u53D1\u9001\u6309\u94AE\uFF0C\u8BF7\u624B\u52A8\u6309 Enter\u3002", sent ? "ok" : "error");
        if (sent) {
          window.setTimeout(() => panel.close(), 700);
        }
      },
      onClose: () => panel.close()
    });
  }
  async function waitForAdapter(timeoutMs = 2e4) {
    const candidates = [new DshAdapter(), new ChatGptAdapter()];
    const startedAt = performance.now();
    while (performance.now() - startedAt < timeoutMs) {
      for (const candidate of candidates) {
        try {
          if (candidate.match(new URL(location.href))) return candidate;
        } catch {
        }
      }
      await sleep(400);
    }
    return null;
  }
  var lastTriggerAt = Number.NEGATIVE_INFINITY;
  function triggerPrompt() {
    const now = performance.now();
    if (now - lastTriggerAt < 400) return;
    lastTriggerAt = now;
    void translatePrompt();
  }
  function replyKeyIsFresh(target) {
    if (translatedReplyKeys.has(target.key)) return false;
    if (lastWrittenText !== "" && target.text.trim() === lastWrittenText.trim()) return false;
    const draft = adapter?.readInput() ?? "";
    if (draft !== "" && target.text.trim() === draft.trim()) return false;
    if (settings.readingLanguage.startsWith("zh") && isMostlyCjk(target.text)) return false;
    if (target.text.trim().length < 8) return false;
    return true;
  }
  async function translateReply(target) {
    try {
      const reply = await sendRuntimeMessage({
        type: "lb:translate",
        request: {
          text: target.text,
          sourceLanguage: "auto",
          targetLanguage: settings.readingLanguage,
          mode: "response"
        }
      });
      if (!reply.ok || reply.skipped) return;
      if (reply.translatedText.trim() === target.text.trim()) return;
      const meta = `${(reply.latencyMs / 1e3).toFixed(1)}s \xB7 ${reply.providerId}`;
      const existing = replyCards.get(target.key);
      if (existing !== void 0 && existing.isConnected) {
        const replacement = createReplyCard({
          translatedText: reply.translatedText,
          meta,
          warnings: reply.warnings
        });
        existing.replaceWith(replacement);
        replyCards.set(target.key, replacement);
        return;
      }
      const card = createReplyCard({ translatedText: reply.translatedText, meta, warnings: reply.warnings });
      adapter?.insertResponseCard(target, card);
      replyCards.set(target.key, card);
      translatedReplyKeys.add(target.key);
    } catch {
    }
  }
  async function checkLatestReply() {
    if (adapter === null || settings.responseMode === "off" || !settings.autoTranslateResponse) return;
    if (!imeGuard.isSafe()) {
      scheduleReplyCheck(1500);
      return;
    }
    const target = adapter.getLatestResponse();
    if (target === null || !replyKeyIsFresh(target)) return;
    const snapshot = replySnapshots.get(target.key);
    if (snapshot !== target.text) {
      replySnapshots.set(target.key, target.text);
      scheduleReplyCheck(1400);
      return;
    }
    await translateReply(target);
  }
  var replySnapshots = /* @__PURE__ */ new Map();
  function scheduleReplyCheck(delayMs = 1400) {
    if (settleTimer !== void 0) window.clearTimeout(settleTimer);
    settleTimer = window.setTimeout(() => {
      settleTimer = void 0;
      void checkLatestReply();
    }, delayMs);
  }
  function isTypingShortcut(event) {
    const key = event.key.toLowerCase();
    return (event.ctrlKey || event.metaKey) && event.altKey && (key === "t" || key === "l");
  }
  function registerShortcuts() {
    document.addEventListener(
      "keydown",
      (event) => {
        if (!isTypingShortcut(event)) return;
        event.preventDefault();
        event.stopPropagation();
        triggerPrompt();
      },
      true
    );
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type !== "lb:command") return;
      if (message.command === "translate-prompt") triggerPrompt();
      if (message.command === "translate-selection") void translateSelection();
    });
  }
  async function bootstrap() {
    if (document.documentElement.dataset["linguabridge"] === "1") return;
    document.documentElement.dataset["linguabridge"] = "1";
    imeGuard.attach();
    settings = await loadSettings();
    wirePanel();
    registerShortcuts();
    adapter = await waitForAdapter();
    if (adapter === null) return;
    launcher = createLauncher(() => {
      triggerPrompt();
    });
    document.documentElement.append(launcher);
    if (settings.autoTranslateResponse && settings.responseMode !== "off") {
      stopObserving = adapter.observeResponses(() => scheduleReplyCheck(1200));
      scheduleReplyCheck(1800);
    }
    try {
      const health = await sendRuntimeMessage({ type: "lb:health" });
      if (!health.healthy) {
        launcher.title = `LinguaBridge\uFF1A\u8FDE\u4E0D\u4E0A ${health.endpoint}\uFF08\u70B9\u300C\u8BD1\u300D\u67E5\u770B\u6307\u5F15\uFF09`;
      }
    } catch {
    }
    try {
      const ping = await sendRuntimeMessage({ type: "lb:ping" });
      extensionVersion = ping.version;
    } catch {
    }
    window.addEventListener("pagehide", () => {
      stopObserving?.();
    });
  }
  void bootstrap().catch((error) => {
    console.warn("[LinguaBridge] bootstrap failed:", error instanceof Error ? error.message : error);
  });
})();
//# sourceMappingURL=content.js.map
